# 773cuisine

Chicago-style food finder. React + Vite + Tailwind, backed by Supabase.

## Deploy (GitHub + Vercel + Supabase)

1. **Push this folder to a new GitHub repo.**
   Easiest on mobile: create a new empty repo on github.com, then use the
   "Add file → Upload files" page and drag in every file/folder here
   (`src/`, `index.html`, `package.json`, etc). Do **not** upload `node_modules`
   (there isn't one yet) or `.env` (it doesn't exist — real keys go in Vercel).

2. **Import the repo into Vercel.**
   vercel.com → New Project → pick this repo. Vercel auto-detects Vite,
   no config needed.

3. **Add environment variables in Vercel** (Project → Settings → Environment
   Variables), using the values from your Supabase project's
   Settings → API page:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`

   Tip: Vercel's Integrations marketplace has a Supabase integration that can
   link an existing project and fill these in for you automatically —
   worth using if you're doing this from a phone, since it skips the
   copy-paste step entirely.

4. **Redeploy.** Vercel picks up the new env vars on the next deploy
   (Deployments tab → ⋯ → Redeploy, if it doesn't happen automatically).

5. Supabase table required (already created if you ran the earlier SQL):

```sql
create table vendors (
  id text primary key,
  name text not null,
  category text not null,
  description text,
  lat double precision not null,
  lng double precision not null,
  added_by text default 'Anonymous',
  added_at timestamptz default now()
);

alter table vendors enable row level security;

create policy "Public read" on vendors for select using (true);
create policy "Public insert" on vendors for insert with check (true);
create policy "Public delete" on vendors for delete using (true);
```

## Local dev

```
npm install
cp .env.example .env   # then fill in your real Supabase URL/key
npm run dev
```

## Notes

- Admin unlock is a simple client-side email check (see `ADMIN_EMAIL` in
  `src/App.jsx`), not real authentication. Fine for friends-and-family use;
  revisit with Supabase Auth if this grows.
- ZIP code and admin status are stored in the browser's `localStorage`
  per-device, not synced across devices.
- The `vendors` table's delete policy is wide open (`using (true)`) to match
  the client-side admin gate — anyone with the anon key can technically
  delete rows via direct API calls. Acceptable for a small launch; lock this
  down with real auth before wider release.
